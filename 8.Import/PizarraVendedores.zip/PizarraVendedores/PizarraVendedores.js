/*
 * Bootstrap-based responsive mashup
 * @owner Enter you name here (xxx)
 */
/*
 *    Fill in host and port for Qlik engine
 */
var prefix = window.location.pathname.substr( 0, window.location.pathname.toLowerCase().lastIndexOf( "/extensions" ) + 1 );

var config = {
	host: window.location.hostname,
	prefix: prefix,
	port: window.location.port,
	isSecure: window.location.protocol === "https:"
};
//to avoid errors in workbench: you can remove this when you have added an app
var app;
require.config( {
	baseUrl: (config.isSecure ? "https://" : "http://" ) + config.host + (config.port ? ":" + config.port : "" ) + config.prefix + "resources"
} );

require( ["js/qlik"], function ( qlik ) {

	var control = false;
	qlik.setOnError( function ( error ) {
		$( '#popupText' ).append( error.message + "<br>" );
		if ( !control ) {
			control = true;
			$( '#popup' ).delay( 1000 ).fadeIn( 1000 ).delay( 11000 ).fadeOut( 1000 );
		}
	} );

	$( "#closePopup" ).click( function () {
		$( '#popup' ).hide();
	} );
	if ( $( 'ul#qbmlist li' ).length === 0 ) {
		$( '#qbmlist' ).append( "<li><a>No bookmarks available</a></li>" );
	}
	$( "body" ).css( "overflow: hidden;" );
	function AppUi ( app ) {
		var me = this;
		this.app = app;
		app.global.isPersonalMode( function ( reply ) {
			me.isPersonalMode = reply.qReturn;
		} );
		
		app.getList( 'SelectionObject', function ( reply ) {
			$( "[data-qcmd='back']" ).parent().toggleClass( 'disabled', reply.qSelectionObject.qBackCount < 1 );
			$( "[data-qcmd='forward']" ).parent().toggleClass( 'disabled', reply.qSelectionObject.qForwardCount < 1 );
		} );
		app.getList( "BookmarkList", function ( reply ) {
			var str = "";
			reply.qBookmarkList.qItems.forEach( function ( value ) {
				if ( value.qData.title ) {
					str += '<li><a data-id="' + value.qInfo.qId + '">' + value.qData.title + '</a></li>';
				}
			} );
			str += '<li><a data-cmd="create">Create</a></li>';
			$( '#qbmlist' ).html( str ).find( 'a' ).on( 'click', function () {
				var id = $( this ).data( 'id' );
				if ( id ) {
					app.bookmark.apply( id );
				} else {
					var cmd = $( this ).data( 'cmd' );
					if ( cmd === "create" ) {
						$( '#createBmModal' ).modal();
					}
				}
			} );
		} );
		$( "[data-qcmd]" ).on( 'click', function () {
			var $element = $( this );
			switch ( $element.data( 'qcmd' ) ) {
				//app level commands
				case 'clearAll':
					app.clearAll();
					break;
				case 'back':
					app.back();
					break;
				case 'forward':
					app.forward();
					break;
				case 'lockAll':
					app.lockAll();
					break;
				case 'unlockAll':
					app.unlockAll();
					break;
				case 'createBm':
					var title = $( "#bmtitle" ).val(), desc = $( "#bmdesc" ).val();
					app.bookmark.create( title, desc );
					$( '#createBmModal' ).modal( 'hide' );
					break;
			}
		} );
	}

	//callbacks -- inserted here --
	//open apps -- inserted here --
	//var app = qlik.openApp('Pizarras_Vendedores.qvf', config);
	var app = qlik.openApp("d4fcafb9-942c-473d-97bb-b6452ecd9330", config);

	//get objects -- inserted here --
	app.getObject('QV80','kmVSSC');
	app.getObject('QV12','QAqwQ');
	app.getObject('QV10','aykf');
	app.getObject('QV04','BEdVTT');
	app.getObject('QV05','DgPnkQ');
	app.getObject('QV02','AvSSjru');
	app.getObject('QV03','cLTbah');
	app.getObject('QV01','hykzS');
	app.getObject('QV79','CUEjYu');
	app.getObject('QV09','uhxxFmp');
	app.getObject('QV08','pwgdMuq');
	app.getObject('QV11','DjCGsU');
	app.getObject('QV06','TxGyt');
	app.getObject('QV07','RECJws');
	
	app.getObject('CurrentSelections','CurrentSelections');
	
	
	app.getObject('QV78','zpEfm');
	app.getObject('QV77','jtTDAmS');
	app.getObject('QV76','fPpvUg');
	app.getObject('QV75','DgFCQmw');
	app.getObject('QV74','beRLE');
	app.getObject('QV73','DsRhP');
	app.getObject('QV72','vCeKkhL');
	app.getObject('QV71','YRybuFJ');
	app.getObject('QV70','UsTptS');
	app.getObject('QV69','vfhBWhC');
	app.getObject('QV68','qf');
	app.getObject('QV67','LPQrPMK');
	app.getObject('QV66','dCHRxfF');
	app.getObject('QV65','hVkpdT');
	app.getObject('QV64','cqAJWmx');
	app.getObject('QV63','PZeQkH');
	app.getObject('QV62','ZvcJJm');
	app.getObject('QV61','BLUBa');
	app.getObject('QV60','NSCxs');
	app.getObject('QV59','AuENeC');
	app.getObject('QV58','pBwyA');
	app.getObject('QV57','ERpLHd');
	app.getObject('QV56','DkZfJ');
	app.getObject('QV55','FTwnaD');
	app.getObject('QV54','YXgjxH');
	app.getObject('QV53','EbJjY');
	app.getObject('QV52','ZDUW');
	app.getObject('QV51','XuFwy');
	app.getObject('QV50','SJped');
	app.getObject('QV49','zcFs');
	app.getObject('QV48','hVepp');
	app.getObject('QV47','ajCjDg');
	app.getObject('QV46','vntGwLu');
	app.getObject('QV45','JrNppw');
	app.getObject('QV44','ZLjLr');
	app.getObject('QV43','MgQx');
	app.getObject('QV42','JhsjWG');
	app.getObject('QV41','FXEaYHG');
	app.getObject('QV40','meBLk');
	app.getObject('QV39','JkCSJB');
	app.getObject('QV38','NapaRL');
	app.getObject('QV37','RPPBQ');
	app.getObject('QV36','QxhJaW');
	app.getObject('QV35','HneTCm');
	app.getObject('QV34','QERy');
	app.getObject('QV33','EPCgjG');
	app.getObject('QV32','RdqjTF');
	app.getObject('QV31','AHDVS');
	app.getObject('QV30','PrFR');
	app.getObject('QV29','sTmfrz');
	app.getObject('QV28','jndFYP');
	app.getObject('QV27','gubkQsG');
	app.getObject('QV26','LCTmgb');
	app.getObject('QV25','KBwE');
	app.getObject('QV24','CWmfxp');
	app.getObject('QV23','xcASE');
	app.getObject('QV22','MzKFbJm');
	app.getObject('QV21','mVzJke');
	app.getObject('QV20','pjesKx');
	app.getObject('QV19','gdFrr');
	app.getObject('QV18','AQGzsJ');
	app.getObject('QV17','prcAWJ');
	app.getObject('QV16','WxepB');
	
	app.getObject('QV15','jFCrcN');
	app.getObject('QV14','gTESgj');
	app.getObject('QV13','gcKmYu');
	//create cubes and lists -- inserted here --
	if ( app ) {
		new AppUi( app );
	}

} );
