
### Button styles

There are several predefined styles available from which you can choose:

> ![]({%= verb.baseImgUrl %}docs/images/sense_navigation_styles.png)

### Button icons
Every button can also include an icon:

> ![]({%= verb.baseImgUrl %}docs/images/sense_navigation_button_icons.png)
